require("babel/register")({stage: 0});

// process.on("unhandledRejection", function (err) {
//   throw err;
// });